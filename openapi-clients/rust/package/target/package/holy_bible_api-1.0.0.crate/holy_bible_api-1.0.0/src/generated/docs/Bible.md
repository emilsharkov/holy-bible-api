# Bible

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bible_id** | **i32** |  | 
**language** | **String** |  | 
**version** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


