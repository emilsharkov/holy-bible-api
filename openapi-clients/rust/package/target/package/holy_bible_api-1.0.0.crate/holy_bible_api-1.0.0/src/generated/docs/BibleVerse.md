# BibleVerse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bible_id** | **i32** |  | 
**book** | **i32** |  | 
**chapter** | **i32** |  | 
**text** | **String** |  | 
**verse** | **i32** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


